package com.example.FaceDetection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaceDetectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
